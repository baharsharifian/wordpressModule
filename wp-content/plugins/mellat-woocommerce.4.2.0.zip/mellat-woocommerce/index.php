<?php
/*
Plugin Name: درگاه پرداخت بانک ملت افزونه ووکامرس نسخه رایگان
Version: 4.2.0
Description:  درگاه پرداخت بانک ملت برای افزونه ووکامرس
Plugin URI: https://woosupport.ir
Author: ووکامرس فارسی
Author URI: https://woosupport.ir
Contributors: Persianscript
WC requires at least: 4.0
WC tested up to: 5.9.0
*/
include_once("class-wc-gateway-bankmellat.php");
//By HANNANStd in PersianScript.ir ==> woocommerce.ir
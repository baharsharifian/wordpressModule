=== درگاه پرداخت بانک ملت ووکامرس ===
author: ووکامرس فارسی
Contributors: Persianscript
author URI: http://www.woosupport.ir/
Donate link: http://www.woosupport.ir/
plugin URI: http://www.woosupport.ir/
Tags: woocommerce, commerce, e-commerce, commerce, shop, virtual shop, mellat bank, mellat, iran, persian, farsi,woocommerce persian, e-commerce, ووکامرس, ووکامرس فارسی,mellat woocommerce,بانک ملت,درگاه پرداخت,payment gateway,mellat,woocommerce payment
Requires at least: 4.0
Tested up to: 5.8.2
Stable tag: 4.2.0

پرداخت اینترنتی وجه به وسیله درگاه پرداخت بانک ملت

== Description ==
**Woocommerce Mellat Bank Gateway** این افزونه شما را قادر می سازد تا براحتی اقدام به ایجاد درگاه پرداخت اینترنتی بانک ملت برای پرداخت های محصولات ووکامرس کنید

= امکانات =
 * سازگار با ووکامرس 2.2.x و 2.3.x و سری 3.x
 * پنل تنظیمات ساده و کاربرپسند
 * تنظیم پیام دلخواه در هنگام پرداخت موفقیت آمیز ، انصراف از پرداخت و یا لغو پرداخت
 * قابلیت نمایش کد رهگیری و شماره ارجاع بانک ملت همراه با کد میانبر
 * نمایش خطاهای درگاه پرداخت
 * قابلیت پرداخت بر اساس واحد پولی ریال و یا تومان و یا هزار تومان و ...
 
 
= نسخه حرفه ای =
 با استفاده از [نسخه حرفه ای درگاه پرداخت بانک ملت ووکامرس](https://woosupport.ir/product/%D8%A7%D9%81%D8%B2%D9%88%D9%86%D9%87-%D8%AF%D8%B1%DA%AF%D8%A7%D9%87-%D9%BE%D8%B1%D8%AF%D8%A7%D8%AE%D8%AA-%D8%A8%D8%A7%D9%86%DA%A9-%D9%85%D9%84%D8%AA-%D9%88%D9%88%DA%A9%D8%A7%D9%85%D8%B1%D8%B3/) قابلیت های جدیدی دریافت کنید.
 * کدنویسی مجدد و رفع خطاهای نسخه های پیشین
 * قابلیت انتقال مستقیم به صفحه بانک بدون نیاز به تایید مجدد
 * وجود حالت اشکال زدایی و نمایش دلیل خطا در صفحه جزئیات سفارش
 
= نیازمندی ها و افزونه های پیشنهادی دیگر =
*  [بسته فارسی ساز ووکامرس](https://wordpress.org/plugins/persian-woocommerce/)
*  [افزونه ارسال پیامک در ووکامرس](https://wordpress.org/plugins/persian-woocommerce-sms/)

= پشتیبانی =
*  [پشتیبانی در ووکامرس فارسی](http://woosupport.ir/)

== Installation ==
1. پوشه `mellat-woocommerce` را در مسیر `/wp-content/plugins/` آپلود کنید
2. افزونه را از طریق منوی 'افزونه ها' در وردپرس فعال کنید
3. تنظیمات افزونه را می توانید از طریق قسمت تنظیمات ووکامرس / تسویه حساب انجام دهید

== Frequently asked questions ==

= Where can I find more information and documentation about the plug-in? =

You can read complete documentations on the [woocommerce.ir](http://www.woosupport.ir)


== Screenshots ==
1. Settings page
2. payment page

== Changelog ==
= 4.2.0 =
* some bug fix
= 4.12.0 =
* رفع چند باگ
= 4.1.0 =
* رفع چند باگ
= 4.1.0 =
* ارائه نسخه حرفه ای افزونه
= 4.0.3 =
* بدون تغییر
= 4.0.2 =
* سازگاری با ووکامرس 2.6
= 4.0.1 =
* سازگاری با واحد پولی هزار تومان و تعریف فیلتر برای واحد های پولی آینده
= 4.0.0 =
* بازنویسی مجدد افزونه و سازگاری با ووکامرس 2.3.x


== Upgrade Notice ==
= 4.2.0 =
* رفع چند باگ

== Traducciones ==
You can read complete documentations on the [woosupport.ir](http://www.woosupport.ir)

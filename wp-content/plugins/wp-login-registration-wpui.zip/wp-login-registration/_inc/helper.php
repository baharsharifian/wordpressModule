<?php
function generate_varification_code(){
    return rand(100000,999999);
}